/**
 Mohamed A. Kamara
 Expressions Wacky
 October 9, 2014
 */
//script to calculate the number of fast food purchase
var weeklyFast = prompt("Weekly visit to McDonald's or Burger King?");
var yrFast = weeklyFast * 52;
alert("You have visited fast food restaurant "+yrFast+ "times this year!");