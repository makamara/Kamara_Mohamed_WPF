/*Mohamed A. Kamara
Expressions Worksheet
October 9, 2014
 */
//Calculate area of a rectangle
var h = 8;
var w=13;
var area=h * w;
console.log(area);

//Calculate the Circumference of a Circle
var radius = 6;
const PI = 3.14159265;

//multiply 2, PI and the radius & assign to circle variable.
var circ = radius * 2 * PI;

//print out the output circumference
Alert("The circumference of the circle is  "+circ);

//Calculate dog year in human year
var humYear=1;
var dogYear=7;
//Dog ages 7 times faster than human
dogYear=dogYear * 7;
alert("The actual age of a dog is  " +dogYear);

//Pizza Party
var pzSlices=12;
var pzOrder=5;
var peopleParty=20;
var totSlices=pzSlices * pzOrder;
var slicePer=(totSlices)/peopleParty;
//Print out slice of pizza per person at the party
alert("Each person ate "+slicePer+ "slices of pizza at the party.");

//Slice of Pie II

var SparkySlice=totslices % peopleParty
alert("Sparky got "+ SparkySlice +"slices of pizza.")


